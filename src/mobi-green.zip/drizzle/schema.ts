import {
  decimal,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  userType: mysqlEnum("userType", ["CLIENT", "DRIVER"]).default("CLIENT").notNull(),
  phone: varchar("phone", { length: 20 }),
  cidade: varchar("cidade", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const fretes = mysqlTable("fretes", {
  id: int("id").autoincrement().primaryKey(),
  clientId: int("clientId").notNull(),
  driverId: int("driverId"),
  origem: text("origem").notNull(),
  destino: text("destino").notNull(),
  valor: decimal("valor", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["OPEN", "ASSIGNED", "DELIVERED", "CANCELLED"])
    .default("OPEN")
    .notNull(),
  cidade: varchar("cidade", { length: 100 }).notNull(),
  origemLat: decimal("origemLat", { precision: 10, scale: 7 }),
  origemLng: decimal("origemLng", { precision: 10, scale: 7 }),
  destinoLat: decimal("destinoLat", { precision: 10, scale: 7 }),
  destinoLng: decimal("destinoLng", { precision: 10, scale: 7 }),
  descricao: text("descricao"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Frete = typeof fretes.$inferSelect;
export type InsertFrete = typeof fretes.$inferInsert;

export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  freteId: int("freteId").notNull(),
  total: decimal("total", { precision: 10, scale: 2 }).notNull(),
  commission: decimal("commission", { precision: 10, scale: 2 }).notNull(),
  driverAmount: decimal("driverAmount", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["PENDING", "PAID", "FAILED"]).default("PENDING").notNull(),
  mpPaymentId: varchar("mpPaymentId", { length: 128 }),
  pixQrCode: text("pixQrCode"),
  pixQrCodeBase64: text("pixQrCodeBase64"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;
