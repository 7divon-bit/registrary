CREATE TABLE `fretes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`clientId` int NOT NULL,
	`driverId` int,
	`origem` text NOT NULL,
	`destino` text NOT NULL,
	`valor` decimal(10,2) NOT NULL,
	`status` enum('OPEN','ASSIGNED','DELIVERED','CANCELLED') NOT NULL DEFAULT 'OPEN',
	`cidade` varchar(100) NOT NULL,
	`origemLat` decimal(10,7),
	`origemLng` decimal(10,7),
	`destinoLat` decimal(10,7),
	`destinoLng` decimal(10,7),
	`descricao` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `fretes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`freteId` int NOT NULL,
	`total` decimal(10,2) NOT NULL,
	`commission` decimal(10,2) NOT NULL,
	`driverAmount` decimal(10,2) NOT NULL,
	`status` enum('PENDING','PAID','FAILED') NOT NULL DEFAULT 'PENDING',
	`mpPaymentId` varchar(128),
	`pixQrCode` text,
	`pixQrCodeBase64` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `userType` enum('CLIENT','DRIVER') DEFAULT 'CLIENT' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(20);--> statement-breakpoint
ALTER TABLE `users` ADD `cidade` varchar(100);